from Tkinter import *
import subprocess
def val(name):
   n=subprocess.check_output("mysql -uroot -pteamlabs@123 ri --disable-column-names -e\"select name from cv where name='"+name+"';\"",shell=TRUE)
   if n=="":
	return -10
   else:
	c1=subprocess.check_output("mysql -uroot -pteamlabs@123 ri --disable-column-names -e\"select skills from cv where name='"+name+"';\"",shell=TRUE)
	c2=subprocess.check_output("mysql -uroot -pteamlabs@123 ri --disable-column-names -e\"select hobbies from cv where name='"+name+"';\"",shell=TRUE)
	c3=subprocess.check_output("mysql -uroot -pteamlabs@123 ri --disable-column-names -e\"select location from cv where name='"+name+"';\"",shell=TRUE)
	c4=subprocess.check_output("mysql -uroot -pteamlabs@123 ri --disable-column-names -e\"select certifications from cv where name='"+name+"';\"",shell=TRUE)
	d=0
	c1=c1.replace('\n','')
	c2=c2.replace('\n','')
	c3=c3.replace('\n','')
	c4=c4.replace('\n','')
	if c1=='python':
		d=100
	if c2=='singing':
		d+=25
	if c3=='nerul':
		d+=50
	if c4!='0':
		d+=25
	return d

