from Tkinter import *
from val import *
import matplotlib.pyplot as plt
root=Tk()
def chart():
   name=entry1.get()
   a=val(name)
   if a==-10:
	fig = plt.figure()
	fig.suptitle("No record of '"+name+"' in database", fontsize=24)
   else:
	sizes=[a,200-a]
	colors = ['green','red']
	fig=plt.pie(sizes, colors=colors, autopct='%1.2f%%')
   plt.show()
frame = Frame(bg="lightblue")
frame.pack()
label1=Label(frame,text="Name")
label1.grid(row=1,column=1)
entry1=Entry(frame)
entry1.grid(row=1,column=2)
btn=Button(frame,text="Submit",command=chart)
btn.grid(row=3,column=2)
root.geometry("600x600")
root.mainloop()
