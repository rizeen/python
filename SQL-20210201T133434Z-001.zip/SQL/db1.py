from tkinter import *
import subprocess, time
root=Tk()
	
def enterindb():
	a=entry1.get()
	b=entry2.get()
	c=entry3.get()
	d=entry4.get()
	print(a,b,c,d)
	subprocess.check_output("mysql -uroot -pteamlabs@123 team -e\"insert into entry(name,location,age,gender) values('"+a+"','"+b+"','"+c+"','"+d+"');\"",shell=TRUE)

label1=Label(root,text='Name',fg='blue')
label2=Label(root,text='Location',fg='blue')
label3=Label(root,text='Age',fg='blue')
label4=Label(root,text='Gender',fg='blue')
label1.grid(row=0,column=0)
label2.grid(row=1,column=0)
label3.grid(row=2,column=0)
label4.grid(row=3,column=0)
entry1=Entry(root,font='Helvetica 10')
entry1.grid(row=0,column=1)
entry2=Entry(root,font='Helvetica 10')
entry2.grid(row=1,column=1)
entry3=Entry(root,font='Helvetica 10')
entry3.grid(row=2,column=1)
entry4=Entry(root,font='Helvetica 10')
entry4.grid(row=3,column=1)
button1=Button(root,text='submit',command=enterindb,bg='lightblue',font='Helvetica 10 bold')
button1.grid(row=4,column=1)

root.geometry('250x150')
root.title('login window')
root.mainloop()
