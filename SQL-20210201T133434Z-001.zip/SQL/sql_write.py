from tkinter import *
import subprocess
root=Tk()
def db():
	check=subprocess.check_output("mysql -uroot -pteamlabs@123 team -e\"insert into employee (id,name,location) values(4,'Rizi','N');\"",shell=TRUE)
	print (check);

button=Button(root,text='CHECK',command=db)
button.grid(row=0,column=0)
root.geometry('500x500')
root.mainloop()
