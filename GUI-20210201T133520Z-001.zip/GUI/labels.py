from Tkinter import *
root=Tk()

label=Label(root,text='name',fg='blue')
#fg=foreground color(text color)
label.pack()
#pack function is used to display anywhere with no defined position
root.mainloop()
#mainloop function helps to acknowledge current status of machine, no need to run the program all the time
