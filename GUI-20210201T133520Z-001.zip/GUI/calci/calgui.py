from tkinter import *
from calguiclas import *

class Calg(Frame,Calgui):
	def __init__ (self,master):
		Frame. __init__ (self,master)
		self.grid()
		self.widget()

	def widget(self):
		self.label1=Label(root,text='n1',fg='blue')
		self.label2=Label(root,text='n2',fg='blue')
		self.label3=Label(root,text='Result',fg='blue')
		self.label1.grid(row=0,column=0)
		self.label2.grid(row=1,column=0)
		self.label3.grid(row=2,column=0)
		self.entry1=Entry(root,font='Helvetica 10')
		self.entry1.grid(row=0,column=1)
		self.entry2=Entry(root,font='Helvetica 10')
		self.entry2.grid(row=1,column=1)
		self.text1=Text(root,height=1,width=20,font='Helvetica 10')
		self.text1.grid(row=2,column=1)
		self.button1=Button(root,text='+',bg='lightblue',font='Helvetica 10 			bold',command=self.add)
		self.button1.grid(row=3,column=0)
		self.button2=Button(root,text='-',bg='lightblue',font='Helvetica 10 			bold',command=self.sub)
		self.button2.grid(row=3,column=1)
		self.button3=Button(root,text='*',bg='lightblue',font='Helvetica 10 			bold',command=self.mul)
		self.button3.grid(row=4,column=0)
		self.button4=Button(root,text='/',bg='lightblue',font='Helvetica 10 			bold',command=self.div)
		self.button4.grid(row=4,column=1)

root=Tk()
b=Calg(root)
root.geometry('500x200')
root.title('login window')
root.mainloop()
