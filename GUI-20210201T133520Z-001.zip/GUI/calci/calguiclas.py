from tkinter import *
class Calgui:
	def add(self):
		a=int(self.entry1.get())
		b=int(self.entry2.get())
		data=a+b
		self.text1.delete(0.0,END)
		self.text1.insert(0.0,data)
	def sub(self):
		a=int(self.entry1.get())
		b=int(self.entry2.get())
		data=a-b
		self.text1.delete(0.0,END)
		self.text1.insert(0.0,data)
	def mul(self):
		a=int(self.entry1.get())
		b=int(self.entry2.get())
		data=a*b
		self.text1.delete(0.0,END)
		self.text1.insert(0.0,data)
	def div(self):
		a=int(self.entry1.get())
		b=int(self.entry2.get())
		data=a/b
		self.text1.delete(0.0,END)
		self.text1.insert(0.0,data)
