from tkinter import *
import random
root=Tk()
def rran():
	x=random.randrange(1,7)
	print(x)
	a=0
	while(a!=x):
		button[a].configure(bg = "red")
		a=a+1
	while(a!=6):
		button[a].configure(bg = "white")
		a=a+1
button=[1,2,3,4,5,6]
button[0]=Button(root,text='1')
button[0].grid(row=0,column=0)
button[1]=Button(root,text='2')
button[1].grid(row=1,column=1)		
button[2]=Button(root,text='3')
button[2].grid(row=2,column=2)
button[3]=Button(root,text='4')
button[3].grid(row=3,column=3)
button[4]=Button(root,text='5')
button[4].grid(row=4,column=4)
button[5]=Button(root,text='6')
button[5].grid(row=5,column=5)
button7=Button(root,text='TOSS',command=rran)
button7.grid(row=7,column=0)
root.geometry('500x500')
root.mainloop()
