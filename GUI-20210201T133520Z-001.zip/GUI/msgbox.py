from tkinter import *
import tkinter.messagebox
tkinter.messagebox.showinfo('xyz','Hello')
a=tkinter.messagebox.askquestion('xyz','How are you?')
if a=='yes':
	print('I am fine')
else:
	print('OKOK')
