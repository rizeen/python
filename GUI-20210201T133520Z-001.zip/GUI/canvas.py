from tkinter import *
root=Tk()
canvas=Canvas(root)
canvas.pack()
canvas.create_rectangle(25,50,75,100,fill='blue')
canvas.create_line(0,100,100,100,fill='red',width='5')
canvas.create_line(0,100,50,0,fill='red')
canvas.create_line(50,0,100,100,fill='red')

root.geometry('400x400')
root.mainloop()
