from Tkinter import *
root=Tk()

label1=Label(root,text='name',bg='',fg='blue')
label1.pack()

label2=Label(root,text='name',bg='',fg='blue')
label2.pack(fill=X)

label3=Label(root,text='name',bg='',fg='blue')
label3.pack(side=LEFT,fill=Y)

root.mainloop()
