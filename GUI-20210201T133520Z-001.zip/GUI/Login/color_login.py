from Tkinter import *
root=Tk()

def verify():
	a=entry1.get()
	b=entry2.get()
	if a=='a' and b=='1':
		data='Welcome'
	else:
		data='Sign up'
	text1.delete(0.0,END)
#deletes the complete text already contained in box,ie. starting from 0.0(start) to end.
	text1.insert(0.0,data)
#inserts data in textbox. Textbox is used to display text in GUI itself, and not in bottom panel like entry.
	
label1=Label(root,text='Name',fg='blue')
label2=Label(root,text='Password',fg='blue')
label3=Label(root,text='Result',fg='blue')
label1.grid(row=0,column=0)
label2.grid(row=1,column=0)
label3.grid(row=2,column=0)
entry1=Entry(root,font='Helvetica 10')
entry1.grid(row=0,column=1)
entry2=Entry(root,font='Helvetica 10')
entry2.grid(row=1,column=1)
text1=Text(root,height=1,width=20,font='Helvetica 10',bg='yellow')
text1.grid(row=2,column=1)
button1=Button(root,text='submit',command=verify,bg='lightblue',font='Helvetica 10 bold')
button1.grid(row=3,column=1)

root.geometry('250x100')
root.title('login window')
root.mainloop()
