from tkinter import *
class Gui2:	
	def verify(self):
		a=self.entry1.get()
		b=self.entry2.get()
		if a=='a' and b=='1':
			data='Welcome'
		else:
			data='Sign up'
		self.text1.delete(0.0,END)
		self.text1.insert(0.0,data)
