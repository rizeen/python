from tkinter import *
from gui2clas import *

class Gui(Frame,Gui2):
	def __init__ (self,master):
		Frame. __init__ (self,master)
		self.grid()
		self.widget()

	def widget(self):
		self.label1=Label(root,text='Name',fg='blue')
		self.label2=Label(root,text='Password',fg='blue')
		self.label3=Label(root,text='Result',fg='blue')
		self.label1.grid(row=0,column=0)
		self.label2.grid(row=1,column=0)
		self.label3.grid(row=2,column=0)
		self.entry1=Entry(root,font='Helvetica 10')
		self.entry1.grid(row=0,column=1)
		self.entry2=Entry(root,font='Helvetica 10')
		self.entry2.grid(row=1,column=1)
		self.text1=Text(root,height=1,width=20,font='Helvetica 10')
		self.text1.grid(row=2,column=1)
		self.button1=Button(root,text='submit',bg='lightblue',font='Helvetica 10 			bold',command=self.verify)
		self.button1.grid(row=3,column=1)
root=Tk()
b=Gui(root)
root.geometry('300x100')
root.title('login window')
root.mainloop()
