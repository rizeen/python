from Tkinter import *
root=Tk()

def verify():
	a=entry1.get()
	b=entry2.get()
	print a,b
	if a=='a' and b=='1':
		print 'welcome'
	else:
		print 'sign up' 

label1=Label(root,text='name')
label2=Label(root,text='password')
entry1=Entry(root)
entry2=Entry(root)
button1=Button(root,text='submit',command=verify)
cbutton=Checkbutton(root,text='keep me logged in')
label1.grid(row=0,column=0,sticky=W)
#grid function is used to display with a defined position, ie. exact location
#keyword sticky shifts the text name to left
label2.grid(row=1,column=0)
entry1.grid(row=0,column=1)
entry2.grid(row=1,column=1)
button1.grid(row=3,column=0)
cbutton.grid(row=3,column=1)

root.geometry('300x100')
root.title('login window')
root.mainloop()
