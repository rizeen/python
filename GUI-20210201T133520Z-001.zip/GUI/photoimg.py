from tkinter import *
root=Tk()
photo=PhotoImage(file='')
label=Label(root,image=photo)
