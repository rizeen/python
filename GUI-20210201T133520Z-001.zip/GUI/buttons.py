from Tkinter import *
root=Tk()

topframe=Frame(root)
topframe.pack()
bottomframe=Frame(root)
bottomframe.pack(side=BOTTOM)
button1=Button(topframe,text='username')
button1.pack(side=LEFT)
button2=Button(topframe,text='password')
button2.pack(side=LEFT)
button3=Button(topframe,text='submit')
button3.pack(side=LEFT)
button4=Button(bottomframe,text='cancel')
button4.pack()

root.mainloop()
