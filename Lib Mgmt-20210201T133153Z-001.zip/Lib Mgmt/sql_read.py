from tkinter import *
import subprocess
root=Tk()
def db():
	check=subprocess.check_output("mysql -uroot -pteamlabs@123 team --disable-column-names -e\"select location from employee where name='xyz';\"",shell=TRUE)
	print (check);

button=Button(root,text='CHECK',command=db)
button.grid(row=0,column=0)
root.geometry('500x500')
root.mainloop()
