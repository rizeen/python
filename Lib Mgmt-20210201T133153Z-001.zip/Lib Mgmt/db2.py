from tkinter import *
import subprocess
root=Tk()
	
def getdata():
	a=entry1.get()
	check1=subprocess.check_output("mysql -uroot -pteamlabs@123 library --disable-column-names -e\"select name from book where id='"+a+"';\"",shell=TRUE)
	check2=subprocess.check_output("mysql -uroot -pteamlabs@123 library --disable-column-names -e\"select author from book where id='"+a+"';\"",shell=TRUE)
	check3=subprocess.check_output("mysql -uroot -pteamlabs@123 library --disable-column-names -e\"select bk_left from book where id='"+a+"';\"",shell=TRUE)
	text1.delete(0.0,END)
	text2.delete(0.0,END)
	text3.delete(0.0,END)
	text1.insert(0.0,check1)
	text2.insert(0.0,check2)
	text3.insert(0.0,check3)
def add():
	a=entry1.get()
	check3=subprocess.check_output("mysql -uroot -pteamlabs@123 library --disable-column-names -e\"select bk_left from book where id='"+a+"';\"",shell=TRUE)
	d=int(check3)+1
	d=str(d)
	subprocess.check_output("mysql -uroot -pteamlabs@123 library -e\"update  book set bk_left='"+d+"' where id='"+a+"';\"",shell=TRUE)

def sub():
	a=entry1.get()
	check3=subprocess.check_output("mysql -uroot -pteamlabs@123 library --disable-column-names -e\"select bk_left from book where id='"+a+"';\"",shell=TRUE)
	d=int(check3)-1
	d=str(d)
	subprocess.check_output("mysql -uroot -pteamlabs@123 library -e\"update  book set bk_left='"+d+"' where id='"+a+"';\"",shell=TRUE)

label1=Label(root,text='bk_ID',fg='blue')
label2=Label(root,text='bk_Name',fg='blue')
label3=Label(root,text='bk_Author',fg='blue')
label4=Label(root,text='Books left',fg='blue')
label1.grid(row=0,column=0)
label2.grid(row=2,column=0)
label3.grid(row=3,column=0)
label4.grid(row=4,column=0)
entry1=Entry(root,font='Helvetica 10')
entry1.grid(row=0,column=1)
text1=Text(root,height=1,width=20,font='Helvetica 10')
text1.grid(row=2,column=1)
text2=Text(root,height=1,width=20,font='Helvetica 10')
text2.grid(row=3,column=1)
text3=Text(root,height=1,width=20,font='Helvetica 10')
text3.grid(row=4,column=1)
button1=Button(root,text='submit',command=getdata,bg='lightblue',font='Helvetica 10 bold')
button1.grid(row=1,column=1)
button2=Button(root,text='+',bg='lightblue',font='Helvetica 10 bold',command=add)
button2.grid(row=5,column=0)
button3=Button(root,text='-',bg='lightblue',font='Helvetica 10 bold',command=sub)
button3.grid(row=5,column=1)

root.geometry('250x200')
root.title('Library Database')
root.mainloop()
