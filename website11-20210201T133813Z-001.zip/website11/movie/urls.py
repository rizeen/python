from django.conf.urls import url
from django.contrib import admin
from . import views

urlpatterns = [
    url(r'^$', views.IndexViews.as_view(), name='index'),
    url(r'^(?P<pk>[0-9]+)$',views.DetailViews.as_view(), name='details'),
    url(r'add/$',views.MovieCreate.as_view(), name='add-movie'),
]
