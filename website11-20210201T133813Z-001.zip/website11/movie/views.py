from django.views import generic
from django.views.generic.edit import *
from .models import Hindi

class IndexViews(generic.ListView):
	template_name='movie/index.html'
	context_object_name='all_movies'
	def get_queryset(self):
		return Hindi.objects.all()
class DetailViews(generic.DetailView):
	model=Hindi
	template_name='movie/details.html'
	context_object_name='movie'
class MovieCreate(CreateView):
	model=Hindi
	fields=['name','actor','actress']
