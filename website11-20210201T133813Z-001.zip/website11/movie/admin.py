from django.contrib import admin
from .models import Hindi, Songs

admin.site.register(Hindi)
admin.site.register(Songs)

admin.site.site_header="Riz Administration"
